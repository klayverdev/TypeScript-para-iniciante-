
//? Aula 2

/* function dizerOla() {
    // console.log("Olá, mundo!");
    return "Olá, mundo!"; // caso queira que retorne algo 
 }


const olaMundo = dizerOla();

console.log(olaMundo); 
----------------------------------------------------------------------- */

//? Aula 3 

/* function juntarPalavras(palavra1: string, palavra2: string, palavra3: number) {
 return `${palavra1} ${palavra2} ${palavra3}`;
}

const resultado = juntarPalavras("Klayver", "Oliveira", 2026);

console.log(resultado); 
------------------------------------------------------------------------- */
//? Aula 4

/* function verificarNumero(n1: number) {
    if (n1 > 0) {
    return `${true}`;
}
    return `${false}`;
}

const resultado2 = verificarNumero(1);
console.log(resultado2); 

-------------------------------------------------------------------------*/

//? Aula 5

//! EXERCICIO: Crie uma função que receba um numero e retorne seu antecessor. Por exemplo, se o numero for 5, a função deve retornar 4.

/*function antecessor(numero: number) {

    return numero - 1;
}

const resultado3 = antecessor(10);
console.log(resultado3);


---------------------------------------------------------------*/
//? Aula 6

//! EXERCICIO: Crie uma função que receba uma variável e retorna seu tipo.Usamos o opedadpr typeof para determinar o tipo da variável.

/*function getValue(value: string) {
   //console.log(typeof 12)
   return typeof value;
    
}
const valor = getValue('Klayver Oliveira');
console.log(valor);


---------------------------------------------------------------*/
//? Aula 7
//! EXERCICIO: Crie uma função que receba dois números e retorna a soma deles se o resultado for posivito ou zero. Se der negativo retorna 'Numero Negativo'

/*function somar(num1: number, num2: number) {

    if (num1 + num2 < 0) {
        return 'Numero Negativo';
    } else {
        return num1 + num2;
    }

}

const valor = somar(5, 0);
console.log(valor);

________________________________________________________________*/
//? Aula 8
//! EXERCICIO: Crie uma função que receba dois valores e retorna a divisão entre eles. Caso não seja possivel realizar a divisão, a função deve retornar um erro 

/*function dividir(num1: number, num2: number) {
    if (num2 === 0) {
        return 'Não é possível dividir por zero';
    }else {
        return num1 / num2;
    }   
   
}

const resultado = dividir(10, 4)
console.log(resultado);
________________________________________________________________*/
//? Aula 9
//! EXERCICIO: Crie uma função que receba dois números e o tipo de operação matemática(soma,subtração,multiplicação ou divisão). A função deve realizar o cálculo com vase na operação matematica fornecida.

function calcular(num1: number, num2: number, operacao: string) {
    switch (operacao) {
        case 'soma': 
            return num1 + num2;
        case 'subtração':
            return num1 - num2;
        case 'multiplicação':
            return num1 * num2;
        case 'divisão':
            if (num2 === 0) {
                return 'Não é possível dividir por zero';
            }else {
                return num1 / num2;
            }   
        default:
            return 'Operação inválida';
    }       
}

const resultado = calcular(1, 0, 'divisão');
console.log(resultado);